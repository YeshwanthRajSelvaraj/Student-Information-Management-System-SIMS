<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .form-container { max-width: 500px; margin: 50px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .btn-primary { background-color: #007bff; border-color: #007bff; }
        .btn-primary:hover { background-color: #0056b3; border-color: #0056b3; }
        .toast-container { position: fixed; top: 20px; right: 20px; z-index: 1050; }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Student Information System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="add.php">Add Student</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Form -->
    <div class="container form-container">
        <h2 class="text-center mb-4">Add New Student</h2>
        <form id="addForm" action="add.php" method="post">
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="age" class="form-label">Age</label>
                <input type="number" class="form-control" id="age" name="age">
            </div>
            <div class="mb-3">
                <label for="course" class="form-label">Course</label>
                <input type="text" class="form-control" id="course" name="course">
            </div>
            <button type="submit" class="btn btn-primary w-100">Add Student</button>
        </form>
    </div>

    <!-- Toast Notification -->
    <div class="toast-container">
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $age = $_POST['age'];
            $course = $_POST['course'];

            $stmt = $conn->prepare("INSERT INTO students (name, email, age, course) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssis", $name, $email, $age, $course);

            if ($stmt->execute()) {
                echo "<div class='toast align-items-center text-bg-success' role='alert' data-bs-autohide='true' data-bs-delay='3000'>
                        <div class='d-flex'>
                            <div class='toast-body'>Student added successfully! <a href='index.php' class='text-white'>View Records</a></div>
                            <button type='button' class='btn-close btn-close-white me-2 m-auto' data-bs-dismiss='toast'></button>
                        </div>
                    </div>";
            } else {
                echo "<div class='toast align-items-center text-bg-danger' role='alert' data-bs-autohide='true' data-bs-delay='3000'>
                        <div class='d-flex'>
                            <div class='toast-body'>Error: " . $stmt->error . "</div>
                            <button type='button' class='btn-close btn-close-white me-2 m-auto' data-bs-dismiss='toast'></button>
                        </div>
                    </div>";
            }
            $stmt->close();
            $conn->close();
        }
        ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize toasts
        document.querySelectorAll('.toast').forEach(toast => new bootstrap.Toast(toast).show());

        // Real-time form validation
        document.getElementById('addForm').addEventListener('submit', function(e) {
            let name = document.getElementById('name').value;
            let email = document.getElementById('email').value;
            if (!name || !email) {
                e.preventDefault();
                alert('Name and Email are required!');
            }
        });
    </script>
</body>
</html>